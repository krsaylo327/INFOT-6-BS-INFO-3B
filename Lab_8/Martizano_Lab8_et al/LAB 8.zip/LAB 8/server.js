const express = require('express');
require('dotenv').config();

const app = express();

if (!process.env.SECRET_KEY) {
  throw new Error("SECRET_KEY not found in environment");
}

app.get('/api/users/:id', (req, res) => {
  const id = req.params.id;
  if (id === '1') {
    res.json({ name: "X" });
  } else if (id === '2') {
    res.json({ name: "Y" });
  } else {
    res.status(404).json({ error: "User not found" });
  }
});

app.listen(3000, () => console.log("Express server running on port 3000"));
