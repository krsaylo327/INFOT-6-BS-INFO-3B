from flask import Flask, jsonify
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

secret_key = os.getenv("SECRET_KEY")
if not secret_key:
    raise Exception("SECRET_KEY not found in environment")

@app.route('/api/users/<int:id>', methods=['GET'])
def get_user(id):
    if id == 1:
        return jsonify({"name": "X"})
    elif id == 2:
        return jsonify({"name": "Y"})
    else:
        return jsonify({"error": "User not found"}), 404

if __name__ == "__main__":
    app.run(port=5001)
