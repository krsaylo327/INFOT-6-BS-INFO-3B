from flask import Flask, jsonify
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)

secret_key = os.getenv("SECRET_KEY")

if not secret_key:
    raise ValueError("SECRET_KEY is missing!")

@app.route('/api/users/<int:id>', methods=['GET'])
def get_user(id):

    if id == 1:
        return jsonify({
            "id": 1,
            "name": "Person X",
            "email": "personx@example.com"
        })

    elif id == 2:
        return jsonify({
            "id": 2,
            "name": "Person Y",
            "email": "persony@example.com"
        })

    else:
        return jsonify({
            "error": "User not found"
        }), 404

if __name__ == "__main__":
    app.run(port=5000)