const express = require("express");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

if (!process.env.SECRET_KEY) {
    console.log("SECRET_KEY missing!");
    process.exit(1);
}

app.get("/api/users/:id", (req, res) => {

    const id = parseInt(req.params.id);

    if (id === 1) {
        return res.json({
            id: 1,
            name: "Person X",
            email: "personx@example.com"
        });
    }

    if (id === 2) {
        return res.json({
            id: 2,
            name: "Person Y",
            email: "persony@example.com"
        });
    }

    return res.status(404).json({
        error: "User not found"
    });

});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});